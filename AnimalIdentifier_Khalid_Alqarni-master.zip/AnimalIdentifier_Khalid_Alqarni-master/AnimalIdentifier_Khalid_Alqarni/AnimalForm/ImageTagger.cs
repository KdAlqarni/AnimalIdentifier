﻿namespace AnimalForm
{
	internal class ImageTagger
	{
	}
}